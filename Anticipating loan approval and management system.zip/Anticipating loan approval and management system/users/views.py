from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
import math
from django.contrib.auth import authenticate, login
from .forms import RegisterForm, LoginForm
import joblib


# Load trained ML model
model = joblib.load("E:/LoanApproval/users/ml_model/loan_model.pkl")

def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Registration successful! You are now logged in.")
            return redirect("dashboard")
        else:
            messages.error(request, "Registration failed. Please correct the errors below.")
    else:
        form = RegisterForm()
    return render(request, "users/register.html", {"form": form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")  #  If logged in, go to dashboard

    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect("dashboard")  #  Redirect only after successful login
    else:
        form = AuthenticationForm()

    return render(request, "users/login.html", {"form": form})

@login_required(login_url="/")
def dashboard_view(request):
    return render(request, "users/dashboard.html")

def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('login')


import random
from .models import LoanApplication  # Import your model
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
@csrf_exempt
def loan_eligibility(request):
    if request.method == "POST":
        try:
            #  Check if JSON data is actually received
            if request.content_type == "application/json":
                data = json.loads(request.body)
            else:
                # Fallback for form submissions
                data = request.POST.dict()

            # Print received data for debugging
            print("Received Data:", data)

            # **Convert Categorical Inputs to Numbers**
            gender_mapping = {"Male": 1, "Female": 0}
            married_mapping = {"Yes": 1, "No": 0}
            education_mapping = {"Graduate": 1, "Not Graduate": 0}
            self_employed_mapping = {"Yes": 1, "No": 0}
            property_area_mapping = {"Urban": 0, "Semiurban": 1, "Rural": 2}

            gender = gender_mapping.get(data.get("gender"), 0)  # Default to 0 if not found
            married = married_mapping.get(data.get("married"), 0)
            dependency = int(data.get("dependency", 0))  # This should be numeric in form
            education = education_mapping.get(data.get("education"), 0)
            self_employed = self_employed_mapping.get(data.get("self_employed"), 0)
            applicant_income = float(data.get("applicant_income", 0))
            coapplicant_income = float(data.get("coapplicant_income", 0))
            loan_amount = float(data.get("loan_amount", 0))
            loan_term = int(data.get("loan_term", 0))
            credit_history = int(data.get("credit_history", 0))
            property_area = property_area_mapping.get(data.get("property_area"), 0)
            interest_rate = float(data.get("interest_rate", 15))

            # conditions
            total_income = applicant_income + coapplicant_income
            monthly_income = total_income / 12

            #  EMI Calculation
            r = (interest_rate / 100) / 12
            n = loan_term

            if r > 0:
                emi = (loan_amount * r * (1 + r) ** n) / ((1 + r) ** n - 1)
            else:
                emi = loan_amount / n

            #  if Applicant Can Afford EMI (Max 60% of Income)

            if credit_history < 5:
                return JsonResponse({"status": "Rejected", "reason": "Credit history must be 5 or above."})

            if loan_term > 60:
                return JsonResponse({"status": "Rejected", "reason": "Loan term should not exceed 5 years."})

            if dependency >= 5:
                return JsonResponse({"status": "Rejected", "reason": "Number of dependents shouldn't be more than 4."})

                # Slightly lower requirement for unmarried female applicants ( Women empowerment )
            if married == 1 and coapplicant_income < (0.3 * applicant_income):
                return JsonResponse({"status": "Rejected", "reason": "Coapplicant income should be at least 30% of applicant income for married applicants."})

            if married == 0 and gender == 0 and coapplicant_income < (0.2 * applicant_income):
                return JsonResponse({"status": "Rejected", "reason": "For unmarried female applicants, coapplicant income should be at least 20% of applicant income."})

            if married == 0 and gender == 1 and coapplicant_income < (0.5 * applicant_income):
                return JsonResponse({"status": "Rejected", "reason": "For unmarried male applicants, coapplicant income should be at least 50% of applicant income."})


            if self_employed == 1 and credit_history < 6:
                return JsonResponse({"status": "Rejected",
                                     "reason": "Self-employed applicants must have a credit history of 6 or above."})

            if education == 0 and loan_term > 37:
                return JsonResponse({"status": "Rejected",
                                     "reason": "Non-graduate applicants cannot request for more than 3 years of loan term."})

            if emi > (0.6 * monthly_income):
                return JsonResponse({
                    "status": "Rejected",
                    "reason": "Applicant income is insufficient to repay the loan in the given term."
                })

            #  Generate Unique Loan ID
            while True:
                loan_id = random.randint(10000, 99999)
                if not LoanApplication.objects.filter(loan_id=loan_id).exists():
                    break

            #  Save to Database (Only if Approved)
            loan_application = LoanApplication(
                loan_id=loan_id,
                gender=gender,
                married=married,
                dependency=dependency,
                education=education,
                self_employed=self_employed,
                applicant_income=applicant_income,
                coapplicant_income=coapplicant_income,
                loan_amount=loan_amount,
                loan_term=loan_term,
                credit_history=credit_history,
                property_area=property_area,
                status="Approved"
            )
            loan_application.save()

            return JsonResponse({"status": "Approved", "loan_id": loan_id})

        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)

    return render(request, "users/loan_eligibility.html")


import json
from django.http import JsonResponse
from django.shortcuts import render

def emi_calculator_view(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode("utf-8"))  # Parse JSON request body
            principal = float(data.get("principal", 0))
            rate = float(data.get("rate", 0)) / 100 / 12  # Convert annual rate to monthly
            tenure = int(data.get("tenure", 1))

            # EMI Calculation
            if rate > 0:
                emi = (principal * rate * (1 + rate) ** tenure) / ((1 + rate) ** tenure - 1)
            else:
                emi = principal / tenure  # Avoid division by zero

            return JsonResponse({"emi": round(emi, 2)})

        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)

    return render(request, "users/emi_calculator.html")


from datetime import datetime
from django.shortcuts import render
from django.http import JsonResponse
from .models import LoanApplication


def loan_status_view(request):
    if request.method == "POST":
        loan_id = request.POST.get("loan_id")
        interest_rate = float(request.POST.get("interest_rate"))
        start_month = int(request.POST.get("start_month"))
        start_year = int(request.POST.get("start_year"))
        current_month = int(request.POST.get("current_month"))
        current_year = int(request.POST.get("current_year"))

        try:
            # Retrieve Loan Details
            loan = LoanApplication.objects.get(loan_id=loan_id)

            # Calculate EMI using the new interest rate
            P = float(loan.loan_amount)
            r = (interest_rate / 100) / 12  # Monthly interest rate
            n = int(loan.loan_term)

            emi = (P * r * (1 + r)**n) / ((1 + r)**n - 1) if r > 0 else P / n

            # Calculate remaining months
            total_months = loan.loan_term
            start_date = datetime(start_year, start_month, 1)
            current_date = datetime(current_year, current_month, 1)
            elapsed_months = (current_date.year - start_date.year) * 12 + (current_date.month - start_date.month)
            pending_months = max(total_months - elapsed_months, 0)

            return JsonResponse({
                "status": loan.status,
                "loan_id": str(loan.loan_id),
                "loan_amount": float(loan.loan_amount),
                "tenure_months": total_months,
                "interest_rate": interest_rate,
                "emi": round(emi, 2),
                "pending_months": pending_months
            })

        except LoanApplication.DoesNotExist:
            return JsonResponse({"status": "Not Found"}, status=404)

    return render(request, "users/loan_status.html")
