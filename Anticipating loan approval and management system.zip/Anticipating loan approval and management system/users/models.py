from django.db import models
from django.contrib.auth.models import AbstractUser
import random

class CustomUser(AbstractUser):
    """ Custom User Model """
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.username


def generate_loan_id():
    """ Generate a unique 6-digit Loan ID """
    return random.randint(100000, 999999)


class LoanApplication(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, null=True)  # ✅ Add relationship
    loan_id = models.IntegerField(unique=True, default=generate_loan_id)
    gender = models.IntegerField()
    married = models.IntegerField()
    dependency = models.IntegerField()
    education = models.IntegerField()
    self_employed = models.IntegerField()
    applicant_income = models.FloatField()
    coapplicant_income = models.FloatField()
    loan_amount = models.FloatField()
    loan_term = models.IntegerField(default=12)
    credit_history = models.IntegerField()
    property_area = models.IntegerField()
    status = models.CharField(max_length=10)  # Approved or Rejected

    def calculate_emi(self):
        """ EMI Calculation """
        principal = float(self.loan_amount)
        rate = 10 / 12 / 100  # ✅ Replace with actual interest rate logic
        tenure = self.loan_term

        if rate > 0:
            emi = (principal * rate * (1 + rate) ** tenure) / ((1 + rate) ** tenure - 1)
        else:
            emi = principal / tenure  # No interest case

        return round(emi, 2)

    def __str__(self):
        user_name = self.user.username if self.user else "No User"
        return f"Loan #{self.loan_id} - {user_name} ({self.status})"


class LoanEligibility(models.Model):
    """ Loan Eligibility Model """
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    credit_history = models.IntegerField(default=0)
    monthly_income = models.DecimalField(max_digits=10, decimal_places=2)
    credit_score = models.IntegerField()
    eligible_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def __str__(self):
        return f"{self.user.username} - Eligibility: {self.eligible_amount}"
