from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views

urlpatterns = [
    # Admin Panel
    path("admin/", admin.site.urls),

    # User Authentication & Features
    path("", include("users.urls")),  # Includes all user-related views

    # Custom Login Page
    path("login/", auth_views.LoginView.as_view(template_name="users/login.html"), name="login"),
]
